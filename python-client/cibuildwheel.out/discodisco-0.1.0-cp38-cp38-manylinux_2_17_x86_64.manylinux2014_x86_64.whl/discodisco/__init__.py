# -*- coding: utf-8 -*-

"""Top-level package for pydisco."""

__author__ = """romnn"""
__email__ = "contact@romnn.com"
__version__ = "0.1.0"

from disco import *
